import React, { Component } from 'react';
signIn= async(email, password) => {
  firebase
  .auth()
  .signInWithEmailAndPassword(email,password)
  .then(()=> {
    this.props.navigation.replace("Dashboard")
  })
.catch(error=>{
  Alert.alert(error.message);
  })
  render() {
    if(!this.state.fontsLoaded){
      return <AppLoading />
    }
    else{
      return (
        <View 
        style={{
          flex:1
          justifyContent:"center"
          alignItems:"center"
          }}>
          <Button
          title="Sign in with Google"
          onPress={()=> this.signInWithGoogleAsync()}></Button>
          </View>
      )
    }
  }
  }


